<?php
session_start();

include "db.php";

if(isset($_GET['action']) && $_GET['action'] == "delete"){
  $query = "
  DELETE FROM
    users
  WHERE 
    id = '" . $_GET['id'] . "'
  ";
  $mysqli->query($query);

  header('location: index.php');
}

if(isset($_POST['new_username'])){
  
  $query = "
    INSERT INTO 
      users 
        (name, surname, username, email, password, age)
      VALUES 
        ('" . $_POST['new_name'] . "', '" . $_POST['new_surname'] . "', '" . $_POST['new_username'] . "', '" . $_POST['new_email'] . "', md5('" . $_POST['new_password'] . "'), '" . $_POST['new_age'] . "')";
  $mysqli->query($query);
  
  header("location: index.php");
}

if(isset($_POST['username'])){
  $query = "
    SELECT
      *
    FROM
      users
    WHERE 
      username = '" . $_POST['username'] . "'
      AND password = md5('" . $_POST['password'] . "')
  ";

  $result = $mysqli->query($query);

  while($row = mysqli_fetch_array($result)){
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['username'] = $row['username'];
    $_SESSION['name_surname'] = $row['name'] . " " . $row['surname'];
  }

  header("location: index.php");    
}

include "header.php";

?>

      <div class="row">
        <div class="col-lg-9">
          
          <h1>Tekstas</h1>
          <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p>

          <h2>Naujas vartotojas</h2>
          <form action="index.php" method="post">
              <b>Name:</b><br /> <input type="text" name="new_name"><br />
              <b>Surname:</b><br /> <input type="text" name="new_surname"><br />
              <b>Username:</b><br /> <input type="text" name="new_username"><br />
              <b>Email:</b><br /> <input type="text" name="new_email"><br />
              <b>Password:</b><br /> <input type="password" name="new_password"><br />
              <b>Age:</b><br /> <input type="text" name="new_age"><br /><br />
              <input type="submit" class="btn btn-primary"  name="new" value="Add"><br /><br />
          </form>
          <hr><br /><br />
          <h2>Vartotojų sąrašas</h2>
          <ul>
          <?php

          $query = "
            SELECT
              *
            FROM
              users
            ORDER BY
              name, surname
          ";

          $result = $mysqli->query($query);

          echo "<table>";
          while($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td><a href='user.php?id=" . $row['id'] . "'>" . $row['name'] . " " . $row['surname'] . "</a></td>";
            echo "<td><a style='color: red;' href='index.php?action=delete&id=" . $row['id'] . "'>X</a></td>";
            echo "</tr>";
          } 
          echo "</table>";
          ?>
        </ul>
        </div>
        <?php
          include "sidebar.php";
        ?>
      </div>
<?php
   include "footer.php";
?>