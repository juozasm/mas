<?php
session_start();

include "db.php";
include "header.php";

$page_id = $_GET['id'];
$action = "";
if(isset($_GET['action'])){
	$action = $_GET['action'];
}


if($action == "like"){
	$query = "
		INSERT INTO 
			user_liked_pages
			(user_id, page_id)
		VALUES
			('" . $_SESSION['user_id'] . "', '" . $page_id . "')
	";
	$mysqli->query($query);
	header("location: page.php?id=" . $page_id);
}
else if($action == "unlike"){
	$query = "
		DELETE FROM
			user_liked_pages
		WHERE 
			user_id = '" . $_SESSION['user_id'] . "'
			AND page_id = '" . $page_id . "'
	";
	$mysqli->query($query);
	header("location: page.php?id=" . $page_id);
}

$query = "
	SELECT
		*
	FROM 
		pages
	WHERE
		id = '" . $page_id . "'
";

$results = $mysqli->query($query);
$row = mysqli_fetch_assoc($results);

?>
<div class="row">
    <div class="col-lg-9">
        <h1><?php echo $row['page']; ?></h1>
        <?php
        if(isset($_SESSION['user_id'])){
			$query = "
				SELECT 
					id
				FROM
					user_liked_pages
				WHERE
					user_id = '" . $_SESSION['user_id'] . "'
					AND page_id = '" . $page_id . "' 
			";

			$results = $mysqli->query($query);
			if($results->num_rows == 0){
				echo "<a href='page.php?id=" . $page_id . "&action=like'>Pamėgti</a>";
			}
			else{
				echo "<a href='page.php?id=" . $page_id . "&action=unlike'>Nebemėgti</a>";
			}
		}
        ?>
        <p class="lead"><?php echo $row['description']; ?></p> 

        <h2>Vartotojai pamėgę šį puslapį</h2>
        <ul>
        	<?php
        	$query = "
        		SELECT
					users.id, users.name, users.surname, users.username
				FROM 
					user_liked_pages
				LEFT JOIN
					users	
						ON
							users.id = user_liked_pages.user_id
				WHERE
					user_liked_pages.page_id = '" . $page_id . "'
        	";

        	$results = $mysqli->query($query);

        	while($row = mysqli_fetch_assoc($results)){
        		echo "<li><a href='user.php?id=" . $row['id'] . "'>" . $row['name'] . " " . $row['surname'] . " (" . $row['username'] . ")</a></li>";
        	}
        	?>
        </ul>
    </div>
    <?php
      include "sidebar.php";
    ?>
</div>

<?php

include "footer.php";

?>