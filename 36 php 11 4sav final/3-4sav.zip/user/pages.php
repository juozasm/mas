<?php
session_start();

include "db.php";

include "header.php";

?>
<div class="row">
    <div class="col-lg-9">
          <h1>Pages</h1>
          <p class="lead">Informacija apie puslapius</p> 

          <?php
          	$query = "
				SELECT
					pages.*, COUNT(user_liked_pages.page_id) as viso
				FROM 
					pages
				LEFT JOIN
					user_liked_pages
						ON
							pages.id = user_liked_pages.page_id
				GROUP BY 
					pages.id
				ORDER BY
					pages.page
			";

			$results = $mysqli->query($query);

			echo "<ul>";
			while($row = mysqli_fetch_assoc($results)){
				echo "<li>";
				echo "<a href='page.php?id=" . $row['id'] . "' >" . $row['page'] . " (" . $row['viso'] . ")</a>";
				echo "</li>";
			}
			echo "</ul>";

			?>
    </div>
    <?php
      include "sidebar.php";
    ?>
</div>

<?php

include "footer.php";

?>