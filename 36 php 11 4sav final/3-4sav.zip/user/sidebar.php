<div class="col-lg-3">
  <h2>Navigacija</h2>
  <ul>
    <li>
      <a href="index.php">Home</a>
    </li>
    <li>
      <a href="pages.php">Pages</a>
    </li>
  </ul>
  <?php

  if(isset($_SESSION['name_surname'])){
    echo "<b>" . $_SESSION['name_surname'] . "</b> (" . $_SESSION['username'] . ")<br />";
    echo "<a href='logout.php'>Atsijungti</a>";
  }
  else{
    ?>
    <form action="index.php" method="post">
      <b>Username:</b><br /> <input type="text" name="username"><br />
      <b>Password:</b><br /> <input type="password" name="password"><br /><br />
      <input type="submit" class="btn btn-primary" value="login">
      <a href="forgot.php">Pamiršau slaptažodį</a>
    </form>
    <?php
  }
  ?>
</div>